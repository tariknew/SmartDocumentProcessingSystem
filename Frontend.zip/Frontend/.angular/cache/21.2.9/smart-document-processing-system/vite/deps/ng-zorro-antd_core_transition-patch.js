import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-F27CBZH5.js";
import "./chunk-FMMSXG2I.js";
import "./chunk-GOMI4DH3.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
