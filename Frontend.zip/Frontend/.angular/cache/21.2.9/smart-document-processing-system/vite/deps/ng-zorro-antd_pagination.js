import {
  NzPaginationComponent,
  NzPaginationDefaultComponent,
  NzPaginationItemComponent,
  NzPaginationModule,
  NzPaginationOptionsComponent,
  NzPaginationSimpleComponent
} from "./chunk-BKZPVJK5.js";
import "./chunk-CKUSCN6D.js";
import "./chunk-IYGCEIB7.js";
import "./chunk-TRVR75L7.js";
import "./chunk-IHNCPRDH.js";
import "./chunk-MJ5DGVT4.js";
import "./chunk-ZJ6UMSEE.js";
import "./chunk-FJLHLNUT.js";
import "./chunk-BPQODU3W.js";
import "./chunk-C7N2QQR3.js";
import "./chunk-FPUQ5QZY.js";
import "./chunk-M5JZL2DF.js";
import "./chunk-7NNU45XT.js";
import "./chunk-RJHA5DRM.js";
import "./chunk-BIVMIT3G.js";
import "./chunk-QYDDKLT3.js";
import "./chunk-42ZV4CLT.js";
import "./chunk-C3G3RFTM.js";
import "./chunk-A3RIZ7YL.js";
import "./chunk-VNCZUHDX.js";
import "./chunk-UGPTCUGZ.js";
import "./chunk-YQ3J25QL.js";
import "./chunk-72DKPDI6.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-NLYKJFNG.js";
import "./chunk-UOCXWVNA.js";
import "./chunk-IJXVWNIG.js";
import "./chunk-Q5G6CELX.js";
import "./chunk-A246GWIU.js";
import "./chunk-SJ7HTYTL.js";
import "./chunk-ZO6ILX5Q.js";
import "./chunk-CIL2CBNV.js";
import "./chunk-FMMSXG2I.js";
import "./chunk-GOMI4DH3.js";
export {
  NzPaginationComponent,
  NzPaginationDefaultComponent,
  NzPaginationItemComponent,
  NzPaginationModule,
  NzPaginationOptionsComponent,
  NzPaginationSimpleComponent
};
