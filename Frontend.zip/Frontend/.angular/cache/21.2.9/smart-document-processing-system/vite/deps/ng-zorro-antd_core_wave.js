import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-PBY5DLQD.js";
import "./chunk-IJXVWNIG.js";
import "./chunk-ZO6ILX5Q.js";
import "./chunk-CIL2CBNV.js";
import "./chunk-FMMSXG2I.js";
import "./chunk-GOMI4DH3.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
