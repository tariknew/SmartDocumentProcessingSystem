import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-YQ3J25QL.js";
import "./chunk-72DKPDI6.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-NLYKJFNG.js";
import "./chunk-UOCXWVNA.js";
import "./chunk-IJXVWNIG.js";
import "./chunk-Q5G6CELX.js";
import "./chunk-A246GWIU.js";
import "./chunk-SJ7HTYTL.js";
import "./chunk-ZO6ILX5Q.js";
import "./chunk-CIL2CBNV.js";
import "./chunk-FMMSXG2I.js";
import "./chunk-GOMI4DH3.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
